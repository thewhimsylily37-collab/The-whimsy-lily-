# The Whimsy Lily

A one-page website for The Whimsy Lily, a mother-daughter crochet studio.

## Put this on GitHub and go live (free hosting via GitHub Pages)

1. Go to [github.com](https://github.com) and create a new repository (e.g. `whimsy-lily-site`). Keep it **Public**.
2. On the repo page, click **Add file → Upload files**, and drag in `index.html` (and this `README.md` if you want).
3. Commit the changes.
4. Go to the repo's **Settings → Pages**.
5. Under "Build and deployment," set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`. Click **Save**.
6. Wait a minute, then your site will be live at:
   `https://<your-username>.github.io/<repo-name>/`

## Editing later

Open `index.html` in any text editor (or edit directly on GitHub by clicking the pencil icon on the file). All the text, like the product names and prices, is plain text inside the HTML — search for it and change it directly.

## Connecting the contact form

Right now the form just shows a popup — it doesn't send anywhere yet. To actually receive messages:
1. Sign up at [formspree.io](https://formspree.io) (free tier available).
2. Create a form there and copy the endpoint URL they give you.
3. In `index.html`, find the `<form>` tag and add `action="YOUR_FORMSPREE_URL" method="POST"`.
4. Remove the `e.preventDefault()` line in the `<script>` at the bottom so the form actually submits.

## How ordering works on this site

There's no online checkout — every "Message to Order" button opens a direct chat with your Instagram (`@thewhimsylily`). Customers message you there, and you arrange the order and payment manually. Nothing to set up, but two things to check:

1. **Update the Instagram username.** The buttons currently point to `https://ig.me/m/thewhimsylily`. If that's not your exact handle, open `index.html`, search for `thewhimsylily` in the "Message to Order" links, and swap in your real username.
2. If you'd rather people land on your profile (instead of opening a DM directly), replace `https://ig.me/m/thewhimsylily` with `https://instagram.com/thewhimsylily` throughout.

## Instagram feed

The Instagram tiles are currently placeholders that link out to your profile. To show your *actual* recent posts automatically, you'd need a third-party embed service (e.g. [SnapWidget](https://snapwidget.com) or [Elfsight](https://elfsight.com)) since Instagram doesn't allow free direct embedding — most of these have a free tier for a basic feed widget.
